@extends('layouts.account')
@section('text')Чтобы получить доступ ко всем тренажерам и отключить рекламу надо авторизоваться@endsection
@section('link')href="/sisgnin"@endsection
@section('linktext')Войти@endsection

@section('header')
    Здесь ты можешь создать ЛК или войти если он уже есть
@endsection
@section('content')

    @include('account.includes.banner')
    <section class="about-area section-gap post-content-area" style="    padding: 0;">
        <div class="container">
            <div class="row align-items-center justify-content-center single-post-area" style="padding-top: 40px;">
                <div class="row quotes" style=" width: 100%;">
                    <div class="col-lg-12 form-group" style="text-align: center"><h2>Добро пожаловать<br> в личный кабинет пользователя <b>Mathsimple</b></h2></div>
                    <div class="col-lg-12 form-group">
                        <p>Теперь можно пользоваться всеми тренажерами без ограничений!</p>
                        <p>Также здесь вы можете поменять настройки вашей учетной записи</p>
                    </div>
                </div>
                <div class="row quotes" style=" width: 100%;">
                    <form class="form-area contact-form text-right" id="myForm"  method="POST" action="/auth/update"  style=" width: 100%;">
                        {!! csrf_field() !!}
                        <div class="col-lg-12 form-group" style="text-align: left"><h2>Личные данные</h2></div>
                        <div class="col-lg-12 form-group">
                            <div class="col-lg-6">
                                <input name="name" placeholder="Имя" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Имя'"
                                       class="common-input mb-20 form-control" required="true" type="text"
                                       value="@if(isset(Auth::user()['name'])) {{Auth::user()['name'] }} @endif">

                                <input name="email" placeholder="Email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="this.placeholder = ''"
                                       onblur="this.placeholder = 'Email'" class="common-input mb-20 form-control" required="true" type="email"
                                       value= "@if(isset(Auth::user()['email'])) {{Auth::user()['email'] }} @endif" >

                                <input  style="width: 100%" type="password" name="password" placeholder="Пароль" onfocus="this.placeholder = ''"
                                        onblur="this.placeholder = 'Пароль'" required="true"  class="common-input mb-20 form-control"
                                        value= "">
                            </div>
                            <div class="col-lg-6"></div>
                        </div>
                        <div class="col-lg-12">
                            <div class="col-lg-6">
                                {{--                                <div class="alert-msg" style="text-align: left;">Данные сохранены</div>--}}
                                <button class="primary-btn"  type="submit" style="width: 100%">Сохранить</button>
                            </div>
                            <div class="col-lg-6"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

@endsection
