<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Log;
use App\Models\User;
use function PHPUnit\Framework\isEmpty;
use YooKassa\Client;
use Illuminate\Support\Facades\Auth;
use YooKassa\Model\NotificationEventType;

class AccountController extends Controller
{
    const secret_key = 'live_kUbXSgyewQtI2jUedr_FGpErLmnuM3rjdqNf7X9oUrU';
    const secret_key_test = 'test_M78WJfldgCL9ORraUqd9StJyYKkdpY1UC68tape3c0I';

    public function signin(){
        return view('auth.signin');
    }
    public function start(){
        return view('auth.start');
    }
    public function home(){
       if(Auth::check()){
           return view('account.home');
       }else{
           return redirect()->to('/signin');
       }
    }
    public function tarifs(){
        return view('account.tafifs');
    }
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255|not_regex:/.*http.*/',
            'password' => 'required|max:255',
            'email' => 'required|max:255',
        ]);

        $user = new User();
        $user->fill($request->only($user->getFillable()));
        $user->save();
        Auth::login($user);

        //return view('account.home');
    }

    public function pay(Request $request){
        $client = new Client();
        $client->setAuth('836972', 'test_M78WJfldgCL9ORraUqd9StJyYKkdpY1UC68tape3c0I');
        $response = $client->addWebhook([
            "event" => NotificationEventType::PAYMENT_SUCCEEDED,
            "url"   => "https://www.merchant-website.com/notification_url",
        ]);

        Log::debug('yomanylog'.$request);
    }
}
